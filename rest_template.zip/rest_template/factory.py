import factory
from factory.django import DjangoModelFactory
from .models import *

#create your factory here
